#include"TemporaryData.h"

#ifdef MP_SERVER
#include "../StandaloneServer/db.h"
#endif

DWORD TenviCharacter::id_counter = 1337;

// new character
TenviCharacter::TenviCharacter(std::wstring nName, BYTE nJob_Mask, WORD nJob, WORD nSkin, WORD nHair, WORD nFace, WORD nCloth, WORD nGColor, std::vector<WORD> &nGEquipped) {
	// [MP] 多个玩家线程可能同时创角, 用原子自增避免撞 ID
	id = (DWORD)InterlockedIncrement((volatile LONG *)&id_counter);
	name = nName;
	job_mask = nJob_Mask; // gender and job
	job = nJob;
	skin = nSkin;
	hair = nHair;
	face = nFace;
	cloth = nCloth;
	gcolor = nGColor;
	equipped.resize(15);
	gequipped = nGEquipped;
	gequipped.resize(15);
	// [v54] 新角色默认出生在魔法密林(8003), 之前是 2002(要塞外围地带),
	// 用户实测新角色不在预期地图, 故改回 8003.
	map = 8003;
	map_return = 0;
	// [FIX] 新角色默认 1 级、0 技能点 0 属性点, 一级小号起步(原值是测试模式 30级满点)
	level = 1;
	sp = 0;
	ap = 0;
	stat_str = 10;
	stat_dex = 10;
	stat_hp = 50;
	stat_int = 10;
	stat_mp = 10;
	x = 0.0;
	y = 0.0;
	gold = 0;
}

void TenviCharacter::ReserveId(DWORD maxId) {
	if (maxId >= id_counter) {
		id_counter = maxId + 1;
	}
}

void TenviCharacter::SetMapReturn(WORD map_return_id) {
	map_return = map_return_id;
}

void TenviCharacter::TestSilva() {
	gcolor = 187;
	//hair = 137;
	map = 8003;
	//map = 8037;
	//equipped.clear();
	//equipped.push_back(228); // hat
	//equipped.push_back(105); // overall
	//equipped.push_back(22508); // weapon
	//equipped.push_back(28715); // weapon ava?
	equipped.resize(15);
}

// game related
bool TenviCharacter::UseSP(WORD skill_id) {
	if (0 < sp) {
		sp--;
		for (auto &v : skill) {
			if (v.id == skill_id) {
				v.level++;
				return true;
			}
		}

		TenviSkill learn_skill;
		learn_skill.id = skill_id;
		learn_skill.level = 1;
		skill.push_back(learn_skill);
		return true;
	}
	return false;
}

bool TenviCharacter::UseAP(BYTE stat_id) {
	if (0 < ap) {
		ap--;
		switch (stat_id) {
		case TS_STR: {
			stat_str++;
			return true;
		}
		case TS_DEX: {
			stat_dex++;
			return true;
		}
		case TS_HP: {
			stat_hp++;
			return true;
		}
		case TS_INT: {
			stat_int++;
			return true;
		}
		case TS_MP: {
			stat_mp++;
			return true;
		}
		default:
		{
				break;
		}
		}
	}
	return false;
}

// init
TenviAccount::TenviAccount() {
	// account info
	slot = 6;

	// default characters
	std::vector<WORD> silva_equip;
	silva_equip.push_back(20002);
	silva_equip.push_back(20502);
	silva_equip.push_back(22508);
	TenviCharacter silva(L"Silva", (1 << 4) | 4, 6, 3, 19, 24, 479, 157, silva_equip);
	silva.TestSilva(); // test

	std::vector<WORD> talli_equip;
	talli_equip.push_back(20001);
	talli_equip.push_back(20811);
	talli_equip.push_back(22507);
	TenviCharacter talli(L"Talli", (1 << 4) | 2, 5, 2, 18, 25, 476, 155, talli_equip);


	std::vector<WORD> andras_equip;
	andras_equip.push_back(20310);
	andras_equip.push_back(20500);
	andras_equip.push_back(22500);
	TenviCharacter andras(L"Andras", (1 << 4) | 1, 4, 1, 17, 23, 473, 8, andras_equip);

	characters.push_back(silva);
	characters.push_back(talli);
	characters.push_back(andras);
}


bool TenviAccount::AddCharacter(std::wstring nName, BYTE nJob_Mask, WORD nJob, WORD nSkin, WORD nHair, WORD nFace, WORD nCloth, WORD nGColor, std::vector<WORD> &nGEquipped) {
	if (slot <= GetCharacters().size()) {
		return false;
	}

	TenviCharacter character(nName, nJob_Mask, nJob, nSkin, nHair, nFace, nCloth, nGColor, nGEquipped);
	characters.push_back(character);
	return true;
}

bool TenviAccount::FindCharacter(DWORD id, TenviCharacter *found) {
	for (auto &character : characters) {
		if (character.id == id) {
			*found = character;
			return true;
		}
	}

	found = NULL;
	return false;
}

std::vector<TenviCharacter>& TenviAccount::GetCharacters() {
	return characters;
}

bool TenviAccount::Login(DWORD id) {
	online_id = id;
	return true;
}

TenviCharacter& TenviAccount::GetOnline() {
	for (auto &character : characters) {
		if (character.id == online_id) {
			return character;
		}
	}

	return characters[0];
}

#ifdef MP_SERVER
// 从 DB 载入本账号角色, 替换默认硬编码角色。空账号自动建一个默认角色并存盘。
void TenviAccount::ReloadFromDB() {
	if (account.empty()) {
		return;
	}
	db().upsertAccount(account);
	std::vector<TenviCharacter> list = db().loadChars(account);
	characters.clear();
	DWORD maxId = 1337;
	for (auto &c : list) {
		characters.push_back(c);
		if (c.id > maxId) maxId = c.id;
	}
	TenviCharacter::ReserveId(maxId);
}
#endif